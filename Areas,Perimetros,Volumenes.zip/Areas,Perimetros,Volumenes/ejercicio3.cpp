#include <iostream>
using namespace std;

int main() {
    float lado, area;

    cout << "Ingrese el valor del lado del cuadrado: ";
    cin >> lado;

    area = lado * lado;

    cout << "El área del cuadrado es: " << area << endl;

    return 0; 
}
