#include <iostream>
using namespace std;

int main() {
    int N;
    cout << "Ingrese N: ";
    cin >> N;
    for(int i = 1; i <= N; i++)
        cout << "1/" << i << " ";
    return 0;
}
